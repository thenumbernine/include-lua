/*
 * Copyright 2023 Haiku, Inc. All Rights Reserved.
 * Distributed under the terms of the MIT License.
 */
#ifndef _BSD_PTHREAD_H_
#define _BSD_PTHREAD_H_


// Chris: I think this whole mess is from me merging the circular dependency of time.h and sys/types.h into sys/types.h ...
// that caused me to move sys/types.h and then change everything else that used it
// either way if i had modified time.h, I'd have to be doing this with everything dependent on time.h ...
// the real fix is for someone to remove all circular dependencies in all the system header files and put the mutually used contents in separate files.
//#include_next <pthread.h>
#include <gnu_pthread.h>

#include <features.h>


#ifdef _DEFAULT_SOURCE


#ifdef __cplusplus
extern "C" {
#endif


extern int pthread_attr_get_np(pthread_t thread, pthread_attr_t* attr);


#ifdef __cplusplus
}
#endif


#endif


#endif	/* _BSD_PTHREAD_H_ */

